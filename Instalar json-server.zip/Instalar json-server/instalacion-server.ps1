npm install -g json-server
