CD..

Set-Location C:\Users\alvar\OneDrive\Escritorio\Recetas
json-server recetas.json